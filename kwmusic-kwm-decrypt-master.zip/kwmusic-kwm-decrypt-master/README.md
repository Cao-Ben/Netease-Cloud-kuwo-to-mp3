# kwmusic-kwm-decrypt
酷我音乐kwm解密
可解密原flac文件的kwm，其它没有试过。

usage: Command [sourceFilePath] [destFilePath]


批量：bat同级目录下创建目录Files，放原文件；执行bat，生成Dest文件生成解密的文件。
